# TYBSc Computer Science — Web Technology Practical Slips

Ready-to-upload practice files for the **non-cancelled Web Technology slips**:
**1, 2, 4–13, 18, 19, 21–30** (24 slips total).

## How to use
- **HTML files:** open in a browser, or use VS Code Live Server.
- **Node.js files:** install Node.js, open a terminal in this folder, and run `node filename.js`.
- For file-system slips, run the program in a separate practice folder because some operations create, rename, copy, or delete files.
- Replace sample names, marks, credentials, and file names if your examiner gives different values.

## Files
- `Slip_01_College_Registration.html`
- `Slip_02_Student_Registration.html`
- `Slip_04_Change_Heading.html`
- `Slip_05_Image_Gallery.html`
- `Slip_06_Hover_Styles.html`
- `Slip_07_First_Last_List.html`
- `Slip_08_Change_Image.html`
- `Slip_09_Arrow_Functions.html`
- `Slip_10_Student_Report.html`
- `Slip_11_Total_Average.html`
- `Slip_12_Product_Bill.html`
- `Slip_13_Swap_Destructuring.html`
- `Slip_18_HTTP_Server.js`
- `Slip_19_Async_Login.js`
- `Slip_21_Path_Module.js`
- `Slip_22_Async_File_Operations.js`
- `Slip_23_Create_Write_Read_Append.js`
- `Slip_24_Sync_Async_Comparison.js`
- `Slip_25_Directory_JSON.js`
- `Slip_26_Async_Copy_Rename_Delete.js`
- `Slip_27_Update_JSON.js`
- `Slip_28_Filter_Files.js`
- `Slip_29_File_Stats.js`
- `Slip_30_Mini_File_Manager.js`

These are study/practice solutions. Always follow the exact operations requested on your practical slip.
