const http = require("http");

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html" });
  res.end("<h1>Hello! Welcome to Node.js Server</h1>");
});

server.listen(3000, () => console.log("Open http://localhost:3000"));
