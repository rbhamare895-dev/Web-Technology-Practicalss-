const login = async (username, password) => {
  if (username === "admin" && password === "1234") return "Login successful";
  throw new Error("Invalid username or password");
};

(async () => {
  try {
    console.log(await login("admin", "1234"));
  } catch (err) {
    console.log("Login failed:", err.message);
  }
})();
